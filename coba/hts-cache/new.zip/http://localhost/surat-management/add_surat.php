<br />
<b>Warning</b>:  Undefined array key "nomor_surat" in <b>C:\xampp\htdocs\surat-management\add_surat.php</b> on line <b>13</b><br />
<br />
<b>Warning</b>:  Undefined array key "jenis_surat" in <b>C:\xampp\htdocs\surat-management\add_surat.php</b> on line <b>14</b><br />
<br />
<b>Warning</b>:  Undefined array key "tujuan_surat" in <b>C:\xampp\htdocs\surat-management\add_surat.php</b> on line <b>15</b><br />
<br />
<b>Warning</b>:  Undefined array key "tanggal_surat" in <b>C:\xampp\htdocs\surat-management\add_surat.php</b> on line <b>16</b><br />
<br />
<b>Warning</b>:  Undefined array key "klasifikasi" in <b>C:\xampp\htdocs\surat-management\add_surat.php</b> on line <b>17</b><br />
Surat berhasil ditambahkan.